﻿using com.xross.tools.xdecision;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Diagnostics;

namespace xdecision.test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void testGetDecision()
        {
            XDecisionTree<String> tree;
            try
            {
                // Please revise the path to correct value 
                tree = XDecisionTreeFactory.create<String>("new_file.xdecision");
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.StackTrace);
                return;
            }

            //Verify tree
            MapFacts test;


            test = new MapFacts();
            test.set("factor0", "value1");
            Assert.AreEqual("decision1", tree.get(test));

            test = new MapFacts();
            test.set("factor0", "value2");
            Assert.AreEqual("decision2", tree.get(test));

            test = new MapFacts();
            test.set("factor0", "value1");
            test.set("factor1", "value1");
            Assert.AreEqual("decision3", tree.get(test));

            test = new MapFacts();
            test.set("factor0", "value1");
            test.set("factor1", "value2");
            Assert.AreEqual("decision4", tree.get(test));

            test = new MapFacts();
            test.set("factor0", "value2");
            test.set("factor2", "value1");
            Assert.AreEqual("decision5", tree.get(test));

            test = new MapFacts();
            test.set("factor0", "value2");
            test.set("factor2", "value2");
            Assert.AreEqual("decision6", tree.get(test));
        }
    }
}
