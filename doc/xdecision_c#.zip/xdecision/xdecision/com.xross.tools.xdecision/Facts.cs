using System;

namespace com.xross.tools.xdecision
{
    public interface Facts
    {
        Object get(String name);
    }
}