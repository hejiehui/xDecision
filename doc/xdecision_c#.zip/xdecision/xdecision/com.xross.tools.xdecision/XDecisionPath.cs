using System;
using System.Collections.Generic;

namespace com.xross.tools.xdecision
{
    public class XDecisionPath<T>
    {
        public class XDecisionPathEntry
        {
            private String factorName;
            private Object value;

            public XDecisionPathEntry(String factorName, Object value)
            {
                this.factorName = factorName;
                this.value = value;
            }

            public String getFactorName()
            {
                return factorName;
            }

            public Object getValue()
            {
                return value;
            }
        }

        private IList<XDecisionPathEntry> path;
        private T decision;

        public XDecisionPath(IList<XDecisionPathEntry> path, T decision)
        {
            this.path = path;
            this.decision = decision;
        }

        public int length()
        {
            return path.Count;
        }

        public XDecisionPathEntry getPathEntry(int depth)
        {
            return path[depth];
        }

        public T getDecision()
        {
            return decision;
        }
    }
}