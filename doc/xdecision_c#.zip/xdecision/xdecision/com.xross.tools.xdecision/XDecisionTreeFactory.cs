using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Xml;

namespace com.xross.tools.xdecision
{
    public class XDecisionTreeFactory
    {
        public static readonly String DECISION_TREE = "decision_tree";

        public static readonly String COMMENTS = "comments";
        public static readonly String PARSER = "parser";

        public static readonly String FACTORS = "factors";
        public static readonly String FACTOR = "factor";
        public static readonly String VALUE = "value";

        public static readonly String DECISIONS = "decisions";
        public static readonly String DECISION = "decision";

        public static readonly String PATHS = "paths";
        public static readonly String PATH = "path";

        public static readonly String ID = "id";
        public static readonly String INDEX = "index";


        public static readonly String TOTAL_FACTOR_NUMBER = "total_factor_num";
        public static readonly String TOTAL_DECISION_NUMBER = "total_decision_num";
        public static readonly String TOTAL_PATH_NUMBER = "total_path_num";

        public static readonly String _DECISION = "_decision";
        public static readonly String DELIMITER = "|";
        public static readonly char FACTOR_VALUE_DELIMITER = ':';

        private static readonly XDecisionTreeFactory factory = new XDecisionTreeFactory();

        /**
         * Default implementation which just use the string as value
         * @author Jerry He
         */
        private class StringParser : XDecisionTreeParser
        {

            public Object parseFact(String name, String value)
            {
                return value;
            }

            public Object parseDecision(String name)
            {
                return name;
            }
        }

        private static readonly XDecisionTreeParser defaultParser = new StringParser();

        public static XDecisionTree<T> create<T>(Uri url)
        {
            try
            {
                WebRequest request = WebRequest.Create(url);
                Stream stream = null;
                using (WebResponse response = request.GetResponse())
                {
                    stream = response.GetResponseStream();
                }
                return create<T>(stream);
            }
            catch (Exception)
            {
                throw;
            }
        }

        /**
         * It will first check model file from file path, if it does not exist, it will try classpath then. 
         * @param path
         * @return
         * @throws Exception
         */
        public static XDecisionTree<T> create<T>(String path)
        {
            try
            {
                Stream input;

                if (File.Exists(path))
                    input = new FileStream(path, FileMode.Open, FileAccess.Read);
                else
                {
                    Assembly classLoader = Assembly.GetExecutingAssembly();
                    if (classLoader == null)
                    {
                        classLoader = typeof(XDecisionTreeFactory).Assembly;
                    }

                    String directory = Path.GetDirectoryName(classLoader.Location);
                    String filePath = Path.Combine(directory, path);
                    input = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                }

                return create<T>(input);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public static XDecisionTree<T> create<T>(Stream input)
        {
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(input);
                return factory.create<T>(doc);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                try
                {
                    if (input != null)
                        input.Close();
                }
                catch (Exception)
                {
                }
            }
        }

        private class FactorDefinition
        {
            internal String factorName;
            internal Object[] values;
        }

        public XDecisionTree<T> create<T>(XmlDocument doc)
        {
            try
            {
                XDecisionTree<T> tree = new XDecisionTree<T>();

                XDecisionTreeParser parser = createParser(doc);
                Object[] decisions = createDecisions(doc, parser);
                FactorDefinition[] factors = createFactors(doc, parser);

                XmlNodeList pathNodes = doc.GetElementsByTagName(PATHS).Item(0).ChildNodes;
                int pathLength = pathNodes.Count;

                for (int i = 0; i < pathLength; i++)
                {
                    String[] array = pathNodes.Item(i).InnerText.Split(new String[] { DELIMITER }, StringSplitOptions.RemoveEmptyEntries);   //StringTokenizer t = new StringTokenizer(pathNodes.Item(i).InnerText, DELIMITER);
                    int entryLength = array != null ? array.Length : 0;
                    IList<XDecisionPath<T>.XDecisionPathEntry> entries = new List<XDecisionPath<T>.XDecisionPathEntry>(entryLength);

                    for (int j = 0; j < entryLength; j++)
                    {
                        String pair = array[j];     //t.nextToken();
                        int index = pair.IndexOf(FACTOR_VALUE_DELIMITER);
                        int factorIndex = Int32.Parse(pair.Substring(0, index));
                        int valueIndex = Int32.Parse(pair.Substring(index + 1, pair.Length - 1 - index));
                        FactorDefinition factor = factors[factorIndex];
                        XDecisionPath<T>.XDecisionPathEntry entry = new XDecisionPath<T>.XDecisionPathEntry(factor.factorName, factor.values[valueIndex]);
                        entries.Add(entry);
                    }


                    XDecisionPath<T> path = new XDecisionPath<T>(entries, (T)decisions[getIntAttribute(pathNodes.Item(i), INDEX)]);
                    tree.add(path);
                }

                return tree;
            }
            catch (Exception)
            {
                throw;
            }
        }

        private XDecisionTreeParser createParser(XmlDocument doc)
        {
            try
            {
                XmlNode parserNode = doc.GetElementsByTagName(PARSER).Item(0);
                if (parserNode == null)
                    return defaultParser;

                String parserClassName = parserNode.InnerText;
                if (parserClassName == null || parserClassName.Trim().Equals(""))
                    return defaultParser;

                Type type = null;
                types.TryGetValue(parserClassName.ToLower(), out type);
                return (XDecisionTreeParser)Activator.CreateInstance(type);   //Class.forName(parserClassName).newInstance()
            }
            catch (Exception)
            {
                throw;
            }
        }

        private IDictionary<String, Type> _types = null;

        private IDictionary<String, Type> types
        {
            get
            {
                if (_types == null)
                {
                    _types = new Dictionary<String, Type>();
                    var assemblies = AppDomain.CurrentDomain.GetAssemblies().Where(p => !p.GlobalAssemblyCache);

                    if (assemblies == null)
                        return _types;

                    foreach (var assembly in assemblies)
                    {
                        Type[] definedTypes = assembly.GetTypes();
                        if (definedTypes == null || definedTypes.Length == 0)
                            continue;

                        foreach (var type in definedTypes)
                        {
                            String typeName = type.FullName.ToLower();
                            if (!_types.ContainsKey(typeName))
                                _types.Add(typeName, type);
                        }
                    }
                }

                return _types;
            }
        }

        private FactorDefinition[] createFactors(XmlDocument doc, XDecisionTreeParser parser)
        {
            XmlNodeList factorNodes = doc.GetElementsByTagName(FACTORS).Item(0).ChildNodes;

            FactorDefinition[] factors = new FactorDefinition[factorNodes.Count];
            for (int i = 0; i < factors.Length; i++)
            {
                XmlNode factorNode = factorNodes.Item(i);
                FactorDefinition factor = new FactorDefinition();

                factor.factorName = getAttribute(factorNode, ID);
                factors[getIntAttribute(factorNode, INDEX)] = factor;

                XmlNodeList valueNodes = factorNode.ChildNodes;
                Object[] values = new Object[valueNodes.Count];
                factor.values = values;
                for (int j = 0; j < values.Length; j++)
                {
                    values[j] = parser.parseFact(factor.factorName, valueNodes.Item(j).InnerText);
                }
            }

            return factors;
        }

        private Object[] createDecisions(XmlDocument doc, XDecisionTreeParser parser)
        {
            XmlNodeList decisionNodes = doc.GetElementsByTagName(DECISIONS).Item(0).ChildNodes;
            Object[] decisions = new String[decisionNodes.Count];

            for (int i = 0; i < decisions.Length; i++)
            {
                decisions[getIntAttribute(decisionNodes.Item(i), INDEX)] = parser.parseDecision(getAttribute(decisionNodes.Item(i), ID));
            }

            return decisions;
        }

        private int getIntAttribute(XmlNode node, String attributeName)
        {
            return Int32.Parse(getAttribute(node, attributeName));
        }

        private String getAttribute(XmlNode node, String attributeName)
        {
            XmlNamedNodeMap map = node.Attributes;
            for (int i = 0; i < map.Count; i++)
            {
                if (attributeName.Equals(map.Item(i).Name))
                    return map.Item(i).Value;
            }

            return null;
        }
    }
}