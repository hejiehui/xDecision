using System;
using System.Collections.Generic;

namespace com.xross.tools.xdecision
{
    /**
     * Default implementation, which use a map internally to hold the factory values.
     * This is useful for cases that the calculation of facts is cheap. 
     * @author Jerry He
     */
    public class MapFacts : Facts
    {
        private IDictionary<String, Object> values = new Dictionary<String, Object>();

        public Object get(String name)
        {
            Object o = null;
            values.TryGetValue(name, out o);
            return o ?? new Object();   //in .Net,the key of IDictionary can't be null.
        }

        public void set(String name, Object value)
        {
            if (!values.ContainsKey(name))
                values.Add(name, null);
            values[name] = value;
        }

        public void reset()
        {
            values.Clear();
        }
    }
}